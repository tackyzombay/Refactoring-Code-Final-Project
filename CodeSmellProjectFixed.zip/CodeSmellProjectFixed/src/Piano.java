

import java.util.Random;

public class Piano extends Instrument{
	private int pianoType;
	
	public Piano() {
		super();
		this.pianoType = 1;
	}
	public Piano(Instrument instrument, int pianoType) {
		super(instrument);
		this.pianoType = pianoType;
	}

	public int getPianoType() {
		return pianoType;
	}

	public void setPianoType(int pianoType) {
		this.pianoType = pianoType;
	}

	@Override
	public String generateID() {
		Random rand = new Random();
		return id = "PI" + rand.nextInt(9-0) + rand.nextInt(9-0) + rand.nextInt(9-0);
	}

	@Override
	public int calculatePrice() {
		return pianoType * 5000;
	}
	@Override
	public void view() {
		// TODO Auto-generated method stub
		System.out.printf("%s | %s | %s | %s | %s | %s | %d | -        | -        | %d        \n", generateID(), name, model, color, condition, owner, calculatePrice(), pianoType);
	}


}
