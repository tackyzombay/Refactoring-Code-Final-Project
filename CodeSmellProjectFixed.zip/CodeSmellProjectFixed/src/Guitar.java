import java.util.Random;

public class Guitar extends Instrument{
	private String guitarType;
	
	public Guitar() {
		super();
		this.guitarType = "";
	}
	public Guitar(Instrument instrument, String guitarType) {
		super(instrument);
		this.guitarType = guitarType;
	}

	public String getGuitarType() {
		return guitarType;
	}

	public void setGuitarType(String guitarType) {
		this.guitarType = guitarType;
	}

	@Override
	public String generateID() {
		Random rand = new Random();
		return id = "GU" + rand.nextInt(9-0) + rand.nextInt(9-0) + rand.nextInt(9-0);
	}

	@Override
	public int calculatePrice() {
		return 4000;
	}
	@Override
	public void view() {
		// TODO Auto-generated method stub
		System.out.printf("%s | %s | %s | %s | %s | %s | %d | -        | %s        | -        \n", generateID(), name, model, color, condition, owner, calculatePrice(), guitarType);

	}
}
