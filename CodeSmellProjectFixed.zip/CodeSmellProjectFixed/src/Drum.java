

import java.util.Random;

public class Drum extends Instrument{
	private int drumType;
	
	public Drum() {
		super();
		this.drumType = 1;
	}
	public Drum(Instrument instrument, int drumType) {
		super(instrument);
		this.drumType = drumType;
	}

	public int getDrumType() {
		return drumType;
	}

	public void setDrumType(int drumType) {
		this.drumType = drumType;
	}

	@Override
	public String generateID() {
		Random rand = new Random();
		return id = "DR" + rand.nextInt(9-0) + rand.nextInt(9-0) + rand.nextInt(9-0);
	}

	@Override
	public int calculatePrice() {
		return drumType * 3000;
	}
	@Override
	public void view() {
		// TODO Auto-generated method stub
		System.out.printf("%s | %s | %s | %s | %s | %s | %d | %d        | -        | -        \n", generateID(), name, model, color, condition, owner, calculatePrice(), drumType);
	}

}
