import java.util.*;

public class Main {
	Scanner input = new Scanner(System.in);
	ArrayList<Instrument> arrayInstrument = new ArrayList<>();
	
	public static void start() throws InterruptedException {
		String welcome = "Welcome to MusikHouse";
		
		for(int i=0; i<welcome.length(); i++) {
			char charWelcome = welcome.charAt(i);
			if(i!=welcome.length()-1) {
			System.out.print(charWelcome);
			}
			if(i==welcome.length()-1) {
				System.out.println(charWelcome);
			}
			Thread.sleep(100);
		}
	}
	
	public Instrument inputInstrument(String type) {
		Instrument instrument=null;
		if(type.equals("Drum")) {
			instrument = new Drum();
		}
		else if(type.equals("Guitar")) {
			instrument = new Guitar();
		}
		else if(type.equals("Piano")) {
			instrument = new Piano();
		}
		do {
			System.out.printf("Input %s name [5 - 20 characters]: ", type);
			instrument.setName(input.nextLine());
		}while(instrument.getName().length()<5 || instrument.getName().length()>20);
		
		do {
			System.out.printf("Input model of %s [A | B | C] (Case Insensitive): ", type);
			instrument.setModel(input.nextLine());
		}while(instrument.getModel().equalsIgnoreCase("A")==false && instrument.getModel().equalsIgnoreCase("B")==false && instrument.getModel().equalsIgnoreCase("C")==false);
		
		do {
			System.out.printf("Input %s color [5 - 15 characters]: ", type);
			instrument.setColor(input.nextLine());
		}while(instrument.getColor().length()<5 || instrument.getColor().length()>15);
		
		do {
			System.out.printf("Input %s brand [ Yamaha | Gibson | Ibanez] (Case Sensitive): ", type);
			instrument.setBrand(input.nextLine());
		}while(!instrument.getBrand().equals("Yamaha") && !instrument.getBrand().equals("Gibson") && !instrument.getBrand().equals("Ibanes"));
		
		do {
			System.out.printf("Input %s condition [ New | Used] (Case Sensitive): ", type);
			instrument.setCondition(input.nextLine());
		}while(!instrument.getCondition().equals("New") && !instrument.getCondition().equals("Used"));
		
		do {
			System.out.printf("Input %s owner [5 - 15 characters]: ", type);
			instrument.setOwner(input.nextLine());
		}while(instrument.getOwner().length()<5 || instrument.getOwner().length()>15);
		return instrument;
	}
	
	public void insert() {
		int menuInstrument = 0;
		
		do {
			System.out.println("Please add which instrument to insert:");
			System.out.println("1. Drum");
			System.out.println("2. Guitar");
			System.out.println("3. Piano");
			System.out.println("4. Back");
			menuInstrument = input.nextInt();
			input.nextLine();
			
			Instrument instrument;
			if(menuInstrument==1) {
				instrument = inputInstrument("Drum");
				int drumType;
				
				do {
					System.out.print("Input drum type [1 | 2 | 3]: ");
					drumType = input.nextInt();
					input.nextLine();
				}while(drumType <1 || drumType>3);
				
				arrayInstrument.add(new Drum(instrument, drumType));
				
				System.out.println("Successfully added a new Drum!");
			}
			
			if(menuInstrument==2) {
				instrument = inputInstrument("Guitar");
				String guitarType;
				
				do {
					System.out.print("Input guitar type [Acoustic | Electric: ");
					guitarType = input.nextLine();
				}while(!guitarType.equals("Acoustic") && !guitarType.equals("Electric"));
				
				arrayInstrument.add(new Guitar(instrument, guitarType));
				
				System.out.println("Successfully added a new Guitar!");
			}
			
			if(menuInstrument==3) {
				instrument = inputInstrument("Piano");
				int pianoType;
				
				do {
					System.out.print("Input piano type [7 | 8 | 9]: ");
					pianoType = input.nextInt();
					input.nextLine();
				}while(pianoType <7 || pianoType>9);
				
				arrayInstrument.add(new Piano(instrument, pianoType));
				
				System.out.println("Successfully added a new Piano!");
			}
			if(menuInstrument==1 || menuInstrument==2 || menuInstrument==3) {
				System.out.println("Press Enter to continue");
				input.nextLine();
				menuInstrument = 4;
			}
			
		}while(menuInstrument!=4);
	}
	
	public boolean view() {
		if(arrayInstrument.isEmpty()==true) {
			System.out.println("There is no instrument in this house");
			System.out.println("Press enter to continue...");
			input.nextLine();
			return false;
		}else if(arrayInstrument.isEmpty()==false) {
			System.out.println("ID    | Name    | Model | Price | Color | Condition | Owner | Drum Type | Guitar Type | Piano Type");
			for(Instrument i : arrayInstrument) {
				i.view();
			}
		}
		return true;
	}
	
	public void delete() {
		String id;
		System.out.println("Input instrument ID to delete: ");
		id = input.next();
		for(Instrument i : arrayInstrument) {
			if(i.getId().equals(id)) {
				arrayInstrument.remove(i);
			}
		}
	}
	
	public Main() {
		int menu = 0;
		do {
			System.out.println("=================================");
			System.out.println("            MusikHouse           ");
			System.out.println("=================================");
			System.out.println("      What do you want to do?    ");
			System.out.println("1. View Instrument");
			System.out.println("2. Add Instrument");
			System.out.println("3. Remove Instrument");
			System.out.println("4. Exit");
			System.out.print(">>");
			menu = input.nextInt();
			input.nextLine();
			
			if(menu==1) {
				view();
			}
			
			if(menu==2) {
				insert();
			}
			
			if(menu==3) {
				if(view()) {
					delete();
				}
			}
			
		}while(menu!=4);
		input.close();
	}

	public static void main(String[] args) throws InterruptedException {
		start();
		new Main();
	}

}
