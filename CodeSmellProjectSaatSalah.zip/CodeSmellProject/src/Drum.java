

import java.util.Random;

public class Drum extends Instrument{
	private int drumType;
	
	public Drum() {
		super();
		this.drumType = 1;
	}
	public Drum(String id, String name, String model, String color, String brand, String condition, String owner,
			int drumType) {
		super(id, name, model, color, brand, condition, owner);
		this.drumType = drumType;
	}

	public int getDrumType() {
		return drumType;
	}

	public void setDrumType(int drumType) {
		this.drumType = drumType;
	}

	@Override
	public String generateID() {
		Random rand = new Random();
		return id = "DR" + rand.nextInt(9-0) + rand.nextInt(9-0) + rand.nextInt(9-0);
	}

	@Override
	public int calculatePrice() {
		return drumType * 3000;
	}

}
