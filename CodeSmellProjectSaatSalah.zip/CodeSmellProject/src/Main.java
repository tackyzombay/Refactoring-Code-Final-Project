import java.util.*;

public class Main {
	Scanner input = new Scanner(System.in);
	ArrayList<Instrument> arrayInstrument = new ArrayList<>();
	
	//1. Long Method, 2. Comment
	public Main() {
		int menu = 0;
		
		String id;
		//3. Dead code
		//this is all the variable for insert at menu 2
		String name;
		String model;
		String color;
		String condition;
		String owner;
		int drumType;
		String guitarType;
		int pianoType;
		Random rand = new Random();
		
		
		
		do {
			System.out.println("=================================");
			System.out.println("            MusikHouse           ");
			System.out.println("=================================");
			System.out.println("      What do you want to do?    ");
			System.out.println("1. View Instrument");
			System.out.println("2. Add Instrument");
			System.out.println("3. Remove Instrument");
			System.out.println("4. Exit");
			System.out.print(">>");
			menu = input.nextInt();
			input.nextLine();
			
			//to view instrument
			if(menu==1) {
				if(arrayInstrument.isEmpty()==true) {
					System.out.println("There is no instrument in this house");
					System.out.println("Press enter to continue...");
					input.nextLine();
				}else if(arrayInstrument.isEmpty()==false) {
					//4. Inappropriate Intimacy
					//don't forget to add view when adding new class of instrument
					System.out.println("ID    | Name    | Model | Price | Color | Condition | Owner | Drum Type | Guitar Type | Piano Type");
					for(Instrument i : arrayInstrument) {
						if(i.getClass().getSimpleName().equals("Guitar")) {
							Guitar temp = (Guitar)i;
							System.out.printf("%s | %s | %s | %s | %s | %s | %d | -        | %d        | -        \n", i.generateID(), i.getName(), i.getModel(), i.getColor(), i.getCondition(), i.getOwner(), i.calculatePrice(), temp.getGuitarType());
						}
						else if(i.getClass().getSimpleName().equals("Drum")) {
							Drum temp = (Drum)i;
							System.out.printf("%s | %s | %s | %s | %s | %s | %d | %d        | -        | -        \n", i.generateID(), i.getName(), i.getModel(), i.getColor(), i.getCondition(), i.getOwner(), i.calculatePrice(), temp.getDrumType());
						}
						else if(i.getClass().getSimpleName().equals("Piano")) {
							Piano temp = (Piano)i;
							System.out.printf("%s | %s | %s | %s | %s | %s | %d | -        | -        | %d        \n", i.generateID(), i.getName(), i.getModel(), i.getColor(), i.getCondition(), i.getOwner(), i.calculatePrice(), temp.getPianoType());
						}
					}
				}
			}
			
			//to add instrument
			if(menu==2) {
				int menuInstrument = 0;
				Instrument instrument;
				do {
					System.out.println("Please add which instrument to insert:");
					System.out.println("1. Drum");
					System.out.println("2. Guitar");
					System.out.println("3. Piano");
					System.out.println("4. Back");
					menuInstrument = input.nextInt();
					input.nextLine();
					
					//5. Duplicate Code, 6. Shotgun Surgery
					//to add drum
					if(menuInstrument==1) {
						instrument = new Drum();
						id = "DR" + rand.nextInt(9-0) + rand.nextInt(9-0) + rand.nextInt(9-0);
						
						do {
							System.out.print("Input drum name [5 - 20 characters]: ");
							instrument.setName(input.nextLine());
						}while(instrument.getName().length()<5 || instrument.getName().length()>20);
						
						do {
							System.out.print("Input model of drum [A | B | C] (Case Insensitive): ");
							instrument.setModel(input.nextLine());
						}while(instrument.getModel().equalsIgnoreCase("A")==false && instrument.getModel().equalsIgnoreCase("B")==false && instrument.getModel().equalsIgnoreCase("C")==false);
						
						do {
							System.out.print("Input drum color [5 - 15 characters]: ");
							instrument.setColor(input.nextLine());
						}while(instrument.getColor().length()<5 || instrument.getColor().length()>15);
						
						do {
							System.out.print("Input drum brand [ Yamaha | Gibson | Ibanez] (Case Sensitive): ");
							instrument.setBrand(input.nextLine());
						}while(!instrument.getBrand().equals("Yamaha") && !instrument.getBrand().equals("Gibson") && !instrument.getBrand().equals("Ibanes"));
						
						do {
							System.out.print("Input drum condition [ New | Used] (Case Sensitive): ");
							instrument.setCondition(input.nextLine());
						}while(!instrument.getCondition().equals("New") && !instrument.getCondition().equals("Used"));
						
						do {
							System.out.print("Input drum owner [5 - 15 characters]: ");
							instrument.setOwner(input.nextLine());
						}while(instrument.getOwner().length()<5 || instrument.getOwner().length()>15);
						
						do {
							System.out.print("Input drum type [1 | 2 | 3]: ");
							drumType = input.nextInt();
							input.nextLine();
						}while(drumType <1 || drumType>3);
						//7. Long Parameter List
						arrayInstrument.add(new Drum(instrument.getId(), instrument.getName(), instrument.getModel(), instrument.getColor(), instrument.getBrand(), instrument.getCondition(), instrument.getOwner(), drumType));
						
						System.out.println("Successfully added a new Drum!");
						System.out.println("Press Enter to continue");
						input.nextLine();
						menuInstrument = 4;
					}
					
					//to add guitar
					if(menuInstrument==2) {
						instrument = new Guitar();
						id = "GU" + rand.nextInt(9-0) + rand.nextInt(9-0) + rand.nextInt(9-0);
						
						do {
							System.out.print("Input guitar name [5 - 20 characters]: ");
							instrument.setName(input.nextLine());
						}while(instrument.getName().length()<5 || instrument.getName().length()>20);
						
						do {
							System.out.print("Input guitar of drum [A | B | C] (Case Insensitive): ");
							instrument.setModel(input.nextLine());
						}while(instrument.getModel().equalsIgnoreCase("A")==false && instrument.getModel().equalsIgnoreCase("B")==false && instrument.getModel().equalsIgnoreCase("C")==false);
						
						do {
							System.out.print("Input guitar color [5 - 15 characters]: ");
							instrument.setColor(input.nextLine());
						}while(instrument.getColor().length()<5 || instrument.getColor().length()>15);
						
						do {
							System.out.print("Input guitar brand [ Yamaha | Gibson | Ibanez] (Case Sensitive): ");
							instrument.setBrand(input.nextLine());
						}while(!instrument.getBrand().equals("Yamaha") && !instrument.getBrand().equals("Gibson") && !instrument.getBrand().equals("Ibanes"));
						
						do {
							System.out.print("Input guitar condition [ New | Used] (Case Sensitive): ");
							instrument.setCondition(input.nextLine());
						}while(!instrument.getCondition().equals("New") && !instrument.getCondition().equals("Used"));
						
						do {
							System.out.print("Input guitar owner [5 - 15 characters]: ");
							instrument.setOwner(input.nextLine());
						}while(instrument.getOwner().length()<5 || instrument.getOwner().length()>15);
						
						
						do {
							System.out.print("Input guitar type [Acoustic | Electric: ");
							guitarType = input.nextLine();
						}while(!guitarType.equals("Acoustic") && !guitarType.equals("Electric"));
						
						arrayInstrument.add(new Guitar(instrument.getId(), instrument.getName(), instrument.getModel(), instrument.getColor(), instrument.getBrand(), instrument.getCondition(), instrument.getOwner(), guitarType));
						
						System.out.println("Successfully added a new Guitar!");
						System.out.println("Press Enter to continue");
						input.nextLine();
						menuInstrument = 4;
					}
					
					//to add piano
					if(menuInstrument==3) {
						instrument = new Piano();
						id = "PI" + rand.nextInt(9-0) + rand.nextInt(9-0) + rand.nextInt(9-0);
						
						do {
							System.out.print("Input piano name [5 - 20 characters]: ");
							instrument.setName(input.nextLine());
						}while(instrument.getName().length()<5 || instrument.getName().length()>20);
						
						do {
							System.out.print("Input piano of drum [A | B | C] (Case Insensitive): ");
							instrument.setModel(input.nextLine());
						}while(instrument.getModel().equalsIgnoreCase("A")==false && instrument.getModel().equalsIgnoreCase("B")==false && instrument.getModel().equalsIgnoreCase("C")==false);
						
						do {
							System.out.print("Input piano color [5 - 15 characters]: ");
							instrument.setColor(input.nextLine());
						}while(instrument.getColor().length()<5 || instrument.getColor().length()>15);
						
						do {
							System.out.print("Input piano brand [ Yamaha | Gibson | Ibanez] (Case Sensitive): ");
							instrument.setBrand(input.nextLine());
						}while(!instrument.getBrand().equals("Yamaha") && !instrument.getBrand().equals("Gibson") && !instrument.getBrand().equals("Ibanes"));
						
						do {
							System.out.print("Input piano condition [ New | Used] (Case Sensitive): ");
							instrument.setCondition(input.nextLine());
						}while(!instrument.getCondition().equals("New") && !instrument.getCondition().equals("Used"));
						
						do {
							System.out.print("Input piano owner [5 - 15 characters]: ");
							instrument.setOwner(input.nextLine());
						}while(instrument.getOwner().length()<5 || instrument.getOwner().length()>15);
						
						
						do {
							System.out.print("Input piano type [1 | 2 | 3]: ");
							pianoType = input.nextInt();
							input.nextLine();
						}while(pianoType <1 || pianoType>3);
						
						arrayInstrument.add(new Piano(instrument.getId(), instrument.getName(), instrument.getModel(), instrument.getColor(), instrument.getBrand(), instrument.getCondition(), instrument.getOwner(), pianoType));
						
						System.out.println("Successfully added a new Piano!");
						System.out.println("Press Enter to continue");
						input.nextLine();
						menuInstrument = 4;
					}
					
				}while(menuInstrument!=4);
			}
			
			//to remove instrument
			if(menu==3) {
				//check if array is empty first, then view instrument
				if(arrayInstrument.isEmpty()==true) {
					System.out.println("There is no instrument in this house");
					System.out.println("Press enter to continue...");
					input.nextLine();
				}else if(arrayInstrument.isEmpty()==false) {
					System.out.println("ID    | Name    | Model | Price | Color | Condition | Owner | Drum Type | Guitar Type | Piano Type");
					for(Instrument i : arrayInstrument) {
						if(i.getClass().getSimpleName().equals("Guitar")) {
							Guitar temp = (Guitar)i;
							System.out.printf("%s | %s | %s | %s | %s | %s | %d | -        | %d        | -        \n", i.generateID(), i.getName(), i.getModel(), i.getColor(), i.getCondition(), i.getOwner(), i.calculatePrice(), temp.getGuitarType());
						}
						else if(i.getClass().getSimpleName().equals("Drum")) {
							Drum temp = (Drum)i;
							System.out.printf("%s | %s | %s | %s | %s | %s | %d | %d        | -        | -        \n", i.generateID(), i.getName(), i.getModel(), i.getColor(), i.getCondition(), i.getOwner(), i.calculatePrice(), temp.getDrumType());
						}
						else if(i.getClass().getSimpleName().equals("Piano")) {
							Piano temp = (Piano)i;
							System.out.printf("%s | %s | %s | %s | %s | %s | %d | -        | -        | %d        \n", i.generateID(), i.getName(), i.getModel(), i.getColor(), i.getCondition(), i.getOwner(), i.calculatePrice(), temp.getPianoType());
						}
					}
					
					System.out.println("Input instrument ID to delete: ");
					id = input.next();
					for(Instrument i : arrayInstrument) {
						if(i.getId().equals(id)) {
							arrayInstrument.remove(i);
						}
					}
				}
			}
			
			
		}while(menu!=4);
		input.close();
	}

	public static void main(String[] args) throws InterruptedException {
		//opener, starts when the program first is played
		String welcome = "Welcome to MusikHouse";
		
		for(int i=0; i<21; i++) {
			char charWelcome = welcome.charAt(i);
			if(i!=20) {
			System.out.print(charWelcome);
			}
			if(i==20) {
				System.out.println(charWelcome);
			}
			Thread.sleep(100);
			}
		
		new Main();

	}

}
