

import java.util.Random;

public class Piano extends Instrument{
	private int pianoType;
	
	public Piano() {
		super();
		this.pianoType = 1;
	}
	public Piano(String id, String name, String model, String color, String brand, String condition, String owner,
			int pianoType) {
		super(id, name, model, color, brand, condition, owner);
		this.pianoType = pianoType;
	}

	public int getPianoType() {
		return pianoType;
	}

	public void setPianoType(int pianoType) {
		this.pianoType = pianoType;
	}

	@Override
	public String generateID() {
		Random rand = new Random();
		return id = "PI" + rand.nextInt(9-0) + rand.nextInt(9-0) + rand.nextInt(9-0);
	}

	@Override
	public int calculatePrice() {
		return pianoType * 5000;
	}


}
