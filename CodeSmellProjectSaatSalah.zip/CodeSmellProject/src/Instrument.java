public abstract class Instrument {
	protected String id;
	protected String name;
	protected String model;
	protected String color;
	protected String brand;
	protected String condition;
	protected String owner;
	public Instrument() {
		this.id = "";
		this.name = "";
		this.model = "";
		this.color = "";
		this.brand = "";
		this.condition = "";
		this.owner = "";
		
	}
	public Instrument(String id, String name, String model, String color, String brand, String condition,
			String owner) {
		this.id = id;
		this.name = name;
		this.model = model;
		this.color = color;
		this.brand = brand;
		this.condition = condition;
		this.owner = owner;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getCondition() {
		return condition;
	}
	public void setCondition(String condition) {
		this.condition = condition;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public abstract String generateID();
	
	public abstract int calculatePrice();

}
