

import java.util.Random;

public class Guitar extends Instrument{
	private String guitarType;
	
	public Guitar() {
		super();
		this.guitarType = "";
	}
	public Guitar(String id, String name, String model, String color, String brand, String condition, String owner,
			String guitarType) {
		super(id, name, model, color, brand, condition, owner);
		this.guitarType = guitarType;
	}

	public String getGuitarType() {
		return guitarType;
	}

	public void setGuitarType(String guitarType) {
		this.guitarType = guitarType;
	}

	@Override
	public String generateID() {
		Random rand = new Random();
		return id = "GU" + rand.nextInt(9-0) + rand.nextInt(9-0) + rand.nextInt(9-0);
	}

	@Override
	public int calculatePrice() {
		return 4000;
	}
}
